#library(Rglpk)
# For an intermediate lambda, 
# find new mu and maximum of step size corresponding to new category.
get.new.mu.step <- function(corr.B, d_corr.B, K.B, w.list.B, lam, d_lam)
{    
  tol <- 1e-8 
  feasibility <- TRUE
  num.B.categ <- length(corr.B)
  step.vec <- rep(Inf, num.B.categ)
  #categ <- matrix(0, num.B.categ, 2)
  categ1 <- vector(mode="list", num.B.categ)
  categ2 <- categ1
  
  cand.mu <- rep(0, num.B.categ)
  obj <- c(0,0,1)
  for(j in 1:num.B.categ){
    dir <- rep("<=", 2*K.B[j])
    rhs <- c(-corr.B[[j]]+lam*w.list.B[[j]], corr.B[[j]]+lam*w.list.B[[j]])
    Cmat <- matrix(0, 2*K.B[j], 3)
    Cmat[,1] <- rep(c(-1,1), each=K.B[j])
    Cmat[,2] <- -Cmat[,1]
    Cmat[,3] <- c(-d_corr.B[[j]]-d_lam*w.list.B[[j]],d_corr.B[[j]]-d_lam*w.list.B[[j]])
    
    insol <- Rglpk::Rglpk_solve_LP(obj,Cmat,dir,rhs,max=TRUE)
    step.vec[j] <- insol$solution[3]
    cand.mu[j] <- insol$solution[1]-insol$solution[2]

    tmp <- -corr.B[[j]]+cand.mu[j]

    j1 <- which(abs(tmp+lam*w.list.B[[j]]+ step.vec[j]*(d_corr.B[[j]]+d_lam*w.list.B[[j]]))<tol)
    j2 <- which(abs(tmp-lam*w.list.B[[j]]+ step.vec[j]*(d_corr.B[[j]]-d_lam*w.list.B[[j]]))<tol)
#cat("j1",j1,"\n")
#cat("j2",j2,"\n")
    if(length(j1)==length(j2)){
      if(sum(j1 == j2)==length(j1)){
        #j1 <- j1[1]; j2 <- j2[length(j1)]
        return(list(feasibility=FALSE))
      }
    }  
    if(length(j1)==0)
      j1 <- 0
    #categ[j,] <- c(j1, j2)
    categ1[[j]] <- j1
    categ2[[j]] <- j2
#cat("step.vec[j]", step.vec[j], cand.mu[j], "\n")
    if(step.vec[j] <= 1e-10 & j1==0)
      step.vec[j] <- Inf
  }
  return(list(step.vec=step.vec, categ1=categ1, categ2=categ2, cand.mu=cand.mu, feasibility=feasibility))
}
# For sufficiently large lambda, find lambda and mu.
get.init.solution <- function(corr, w.list, K, tol=1e-9)
{
  diff <- c(); cand.mu <- c()
  p <- length(corr)
  #A.cand <- matrix(0, p, 2)
  A.cand1 <- vector(mode="list",p)
  A.cand2 <- vector(mode="list",p)
  obj <- c(0,0,1)
  
  for(j in 1:p){
    dir <- rep("<=", 2*K[j])
    rhs <- c(corr[[j]], -corr[[j]])
    Cmat <- matrix(0, 2*K[j], 3)
    Cmat[1:K[j],1] <- 1; Cmat[(K[j]+1):(2*K[j]),1] <- -1;
    Cmat[,2] <- -Cmat[,1]
    Cmat[,3] <- c(-w.list[[j]],-w.list[[j]]) # rep(-w.list[[j]],times=2)
  
    insol <- Rglpk::Rglpk_solve_LP(obj,Cmat,dir,rhs,max=FALSE)
    diff[j] <- insol$solution[3]
    #cat("max lambda=", diff[j], "\n")
    cand.mu[j] <- insol$solution[1]-insol$solution[2]
    kkt1 <- -corr[[j]] + cand.mu[j] + diff[j]*w.list[[j]]
    kkt2 <- -corr[[j]] + cand.mu[j] - diff[j]*w.list[[j]]
#    print(min(abs(kkt1)))
#    print(min(abs(kkt2)))
    
    j1 <- which(abs(-corr[[j]] + cand.mu[j] + diff[j]*w.list[[j]])<tol)
    j2 <- which(abs(-corr[[j]] + cand.mu[j] - diff[j]*w.list[[j]])<tol)
#print(which(abs(-corr[[j]] + cand.mu[j] + diff[j]*w.list[[j]])<tol*1))
    A.cand1[[j]] <- j1
    A.cand2[[j]] <- j2
  }
  # Set lambda and mu accordingly
  act.categ <- which.max(diff)
  return(list(act.categ=act.categ, lambda=diff[act.categ], mu=cand.mu[act.categ], A.cand1=A.cand1, A.cand2=A.cand2))
}

#
get.init.solution.simple <- function(corr, w.list)
{
  diff <- c(); cand.mu <- c()
  p <- length(corr)
  #A.cand <- matrix(0, p, 2)
  A.cand1 <- vector(mode="list",p)
  A.cand2 <- vector(mode="list",p)  
  for(j in 1:p){
    wcorr = corr[[j]]/w.list[[j]]
    j1 <- which.max(wcorr); j2 <- which.min(wcorr)
    #A.cand[j,] <- c(j1, j2)
    A.cand1[[j]] <- j1
    A.cand2[[j]] <- j2
    diff[j] <- (corr[[j]][j1]-corr[[j]][j2])/(w.list[[j]][j1]+w.list[[j]][j2])
    cand.mu[j] <- ((corr[[j]][j1]+corr[[j]][j2])-diff[j]*(w.list[[j]][j1]-w.list[[j]][j2]))/2 
  }
  # Set lambda and mu accordingly
  act.categ <- which.max(diff)
  return(list(act.categ=act.categ, lambda=diff[act.categ], mu= cand.mu[act.categ], A.cand1=A.cand1, A.cand2=A.cand2))
} 

# sugar functions
initial.reg <- function(y, gam){
  f <- function(a, y){
    res <- y-a
    ind1 <- abs(res) >= gam
    ind2 <- abs(res) < gam
    
    (sum(res[ind2]^2) + sum(2*gam*abs(res[ind1]) - gam^2))/2
  }    
  xmin <- optimize(f, lower=min(y), upper=max(y), maximum=F, y=y, tol=1e-18)
  beta0 <- xmin$minimum
  return(beta0)
}
initial.class <- function(y, gam){
  f <- function(a, y) {
    res <- y*a
    ind1 <- res <= gam
    ind2 <- res > gam & res < 1
    sum((1-gam^2)-2*(1-gam)*res[ind1])+sum((1-res[ind2])^2)
  }
  xmin <- optimize(f, c(-max(1,abs(gam)), max(1,abs(gam))), maximum=FALSE, y=y)
  beta0 <- xmin$minimum
 
  #if((0 <= gam) & (sum(y)==0)){
  #  cat("sum(y)",sum(y),"\n")
  #  beta0 <- 0      # it is also a optimum
  #}    
  if(abs(beta0)==1 | abs(beta0) == abs(gam)){
    cat("beta0 =", beta0, "\n")
    warning("Initial point at the boundary")
  }
  return(beta0)
}
Res.reg <- function(y,fx){
  drop(y-fx)
}
Res.class <- function(y,fx){
  drop(y*fx)  
}
Sets.reg <- function(seqN,res,gam){
  L <- seqN[res <= -gam]
  R <- seqN[res >= gam]
  E <- setdiff(seqN, union(L,R))    
  list(L=L,E=E,R=R)
}
Sets.class <- function(seqN,res,gam){
  L <- seqN[res <= gam]
  R <- seqN[res >= 1]
  E <- setdiff(seqN, union(L,R))    
  list(L=L,E=E,R=R)    
}
d_getgcorr <- function(tX, d_fx, set){
  return(drop(tX[,set$E,drop=FALSE]%*%d_fx[set$E]))
}
getgcorr.reg <- function(y, tX, res, set, gam){
  tmp <- gam*rowSums(tX[,set$L,drop=FALSE])-gam*rowSums(tX[,set$R,drop=FALSE])
  tmp <- tmp -drop(tX[,set$E,drop=FALSE]%*%res[set$E])
  return(-drop(tmp))
}
getgcorr.class <- function(y, tX, res, set, gam){
  tmp <- (gam-1)*rowSums(tX[,set$L,drop=FALSE]%*%y[set$L])
  tmp <- tmp -drop(tX[,set$E,drop=FALSE]%*%(y[set$E]*(1-res[set$E])))
  return(-drop(tmp))
}
# objetive value
getobjective.res <- function(res, set, gam=gam){
  1/2*sum(res[set$E]^2)+sum(gam*abs(res[union(set$L,set$R)])-gam^2/2)
}
getobjective.class <- function(res, set, gam=gam){
  1/2*(sum((1-gam^2)-2*(1-gam)*res[set$L])+sum((1-res[set$E])^2))
}

Find.Event.sets <- function(ltype, y, res, gam, xv, set, d_beta0, d_beta){
  #ltype="regression"; 
  eps=1e-10; trace=FALSE
  xi <- 1
  
  L <- set$L; E <- set$E; R <- set$R
  nL <- length(L); nE <- length(E); nR <- length(R)

  # set change
  d_score <- drop(d_beta0 + xv %*% d_beta)
  # Event1: 1 and 2
  # A2 point leaves A2 set
  d_E1_pnt = rep(Inf, nE); d_E2_pnt = rep(Inf, nE)
        
  if(ltype=="regression"){
    d_E1_pnt = xi*(res[E]+gam)/d_score[E] # E => L
    d_E2_pnt = xi*(res[E]-gam)/d_score[E] # E => R
  }else{
    d_E1_pnt = xi*y[E]*(gam-res[E])/(d_score[E])
    d_E2_pnt = xi*y[E]*(1-res[E])/(d_score[E])
    flag <- y[E]*d_score[E] >=0
    d_E1_pnt[flag] <- Inf
    flag <- y[E]*d_score[E] <= 0
    d_E2_pnt[flag] <- Inf 
  }
  d_E1_pnt[is.na(d_E1_pnt)] <- Inf        
  d_E1_pnt[d_E1_pnt<eps] <- Inf   
  d_E1 = min(d_E1_pnt)
  
  d_E2_pnt[is.na(d_E2_pnt)] <- Inf
  d_E2_pnt[d_E2_pnt<eps] <- Inf
  d_E2 = min(d_E2_pnt)
        
  # Event2: 3 and 4
  # A1 or A3 points enter into A2 set
  d_E3_pnt <- rep(Inf, nL)
  if(nL !=0){
    if(ltype=="regression"){            
      d_E3_pnt <- xi*(res[L]+gam)/d_score[L]
      #cat(res[L], -gam, d_score[L], "\n")
    }else{
      d_E3_pnt <- xi*y[L]*(gam-res[L])/d_score[L]
    }
    d_E3_pnt[is.na(d_E3_pnt)] <- Inf
    d_E3_pnt[d_E3_pnt<eps] <- Inf
    d_E3 <- min(d_E3_pnt)
  }else{
    d_E3 <- Inf
  }
        
  d_E4_pnt <- rep(Inf, nR)
  if(nR !=0){
    if(ltype=="regression"){
      d_E4_pnt <- xi*(res[R]-gam)/d_score[R]
    }else{
      d_E4_pnt <- xi*y[R]*(1-res[R])/d_score[R]
    }           
    d_E4_pnt[is.na(d_E4_pnt)] <- Inf
    d_E4_pnt[d_E4_pnt<eps] <- Inf
    d_E4 <- min(d_E4_pnt)
  }else{
    d_E4 <- Inf
  }   
  ds <- min(c(d_E1,d_E2,d_E3,d_E4))
  
  EPO = which.min(c(d_E1,d_E2,d_E3,d_E4))
    
  if(trace){
  #if(T){
    #cat("ds    >>> ", ds,  " "); 
    cat("d_E1  >>> ", d_E1,  " "); cat("d_E2  >>> ", d_E2,  " ")
    cat("d_E3  >>> ", d_E3,  " "); cat("d_E4  >>> ", d_E4,  " ")
    cat(">>> Set Event ", EPO, "occurs!!!\n")
  }
  return( list(EPO = EPO, 
               ds = ds, 
         d_E1_pnt = d_E1_pnt,
         d_E2_pnt = d_E2_pnt,
         d_E3_pnt = d_E3_pnt,
         d_E4_pnt = d_E4_pnt
          ))
}

### Function ends
obcoeff <- function(b1, k, p){
  if(k == 1) 
    b1 = c(-sum(b1),b1)
  if(k == p) 
    b1 = c(b1,-sum(b1))
  if(k>1 & k<p) 
    b1 = c(b1[1:(k-1)],-sum(b1), b1[(k):(p-1),])
  b1 
}
obmcoeff <- function(bm, k){
  b <- matrix(0, nrow(bm)+1, ncol(bm))
  for(j in 1:ncol(bm)){
    b[,j] <- obcoeff(bm[,j],k)  
  }
  return(b)
}  


