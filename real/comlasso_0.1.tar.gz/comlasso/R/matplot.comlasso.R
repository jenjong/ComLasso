matplot.comlasso <- function(lam, coef1, cnums,...)
{
  s1 <- 1:length(lam)
  matplot(s1, coef1, ..., type = "b", pch = "*")
  #title(object$type, line = 2.5)
  abline(h = 0, lty = 3)
  axis(4, at = coef1[nrow(coef1), cnums], labels = paste(cnums), 
       cex = 0.8, adj = 0)
  
  if (breaks) {
    axis(3, at = s1, labels = paste(stepid), cex = 0.8)
    abline(v = s1)
  }
}

matplot.comlasso1 <- function(lam, coef1, cnums, breaks=FALSE, ...)
{
  #s1 <- 1:length(lam)
  # coef1 steps times num of variables
  S <- sum(abs(coef1[nrow(coef1),]))
  s1 <- rowSums(abs(coef1))/S

  matplot(s1, coef1, ..., type="b", pch="*")
  #title(object$type, line = 2.5)
  abline(h = 0, lty = 3)
  axis(4,at=coef1[nrow(coef1),cnums[c(1,4,7,8,9)]],labels=paste(cnums[c(1,4,7,8,9)]), 
       cex=0.8,cex.lab=0.3,line=0) # adj=0
  axis(4,at=coef1[nrow(coef1),cnums[c(2,3,5,6,10)]],labels=paste(cnums[c(2,3,5,6,10)]), 
       cex=0.8,cex.lab=0.3,tick=FALSE,line=1)
  
  stepid = trunc(as.numeric(dimnames(coef1)[[1]])) # rownames
  
  if (breaks) {
    axis(3, at = s1, labels = paste(stepid), cex = 0.8)
    abline(v = s1)
  }
}