graph_path_comlasso <-
function(obj, ...){
  #bb <- t(rbind(obj$beta0.rec,obj$beta.rec[[1]]))
  frac <- seq(0,1,by=0.1)
  #coeff <- predict.comlasso(obj$lambda,bb,s=frac,
  coeff <- predict.comlasso(obj,s=frac, 
    type="coefficients",mode="fraction")$coefficients
  matplot(frac,coeff[,-1],type="b",
    xlab=expression(sum(abs(beta[j](lambda)))/sum(abs(beta[j](0)))),
    ylab=expression(hat(beta)[j](lambda)),...)
  abline(h=0, lwd=0.2, lty=2)
}
