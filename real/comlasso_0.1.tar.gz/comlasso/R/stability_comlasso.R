# based on  JP Vert, 14/9/2010
#Stability selection in the spirit of Meinshausen&Buhlman
stable_reg_comlasso <- function(x,y,gam=1,nbootstrap=100,
  nsteps=20,alpha=0.2,plotme=FALSE,trace=FALSE)
{
  # x is the n*p design matrix, y the n*1 variable to predict
  # x should be normalized to unit variance per column 
  # before calling this function (if you want to)
  # the result is a score (length p) for each feature, 
  # the probability that each feature is selected 
  # during the first nsteps steps of the Lasso path 
  # when half of the samples are used and 
  # the features are reweigthed by a random weight uniformaly sampled in [alpha,1]. 
  # This probability is estimated by nbootstrap bootstrap samples

  dimx <- dim(x); n <- dimx[1]; kp <- dimx[2]
  halfsize <- as.integer(n/2)
  freq <- matrix(0,kp,nsteps+1)
  
  for(i in seq(nbootstrap)){
    # Randomly reweight each variable
    # xs <- t(t(x)*runif(p,alpha,1))
    
    # Ramdomly split the sample in two sets
    perm <- sample(dimx[1])
    i1 <- perm[1:halfsize]; 
    i2 <- perm[(halfsize+1):n]
   
    # run the randomized lasso on each sample and 
    # check which variables are selected
    w <- runif(kp,alpha,1)
    r <- comlasso("regression", halfsize, p=1, K=kp, x[i1,], y[i1], gam, weights=w, 
          max.steps=nsteps, trace=trace)
    bvec <- r$beta.rec[[1]]
    freq <- freq + abs(sign(bvec))
    
    w <- runif(kp,alpha,1)
    r <- comlasso("regression", halfsize, p=1, K=kp, x[i2,], y[i2], gam, weights=w, 
          max.steps=nsteps, trace=trace)
    bvec <- r$beta.rec[[1]]
    freq <- freq + abs(sign(bvec))
  }
  # normalize frequence in [0,1]
  freq <- freq/(2*nbootstrap)
  
  if(plotme){
    matplot(t(freq),type='l',xlab="CLasso iteration",ylab="Frequency", ylim=c(0,1))
  }
  # the final stability score is the maximum frequency over the steps
  result <- apply(freq,1,max)
  return(result)
}
# classification
stable_class_comlasso <- function(x,y,gam=0,nbootstrap=100,
  nsteps=20,alpha=0.2,plotme=FALSE,trace=FALSE)
{
  # x is the n*p design matrix, y the n*1 variable to predict
  # x should be normalized to unit variance per column 
  # before calling this function (if you want to)
  # the result is a score (length p) for each feature, 
  # the probability that each feature is selected 
  # during the first nsteps steps of the Lasso path 
  # when half of the samples are used and 
  # the features are reweigthed by a random weight uniformaly sampled in [alpha,1]. 
  # This probability is estimated by nbootstrap bootstrap samples

  dimx <- dim(x); 
  n <- dimx[1]; kp <- dimx[2]
  seqN <- 1:n
  pidx <- seqN[y==1]; lp <- length(pidx)
  nidx <- seqN[y==-1]; ln <- length(nidx)
  
  freq <- matrix(0,kp,nsteps+1)
  
  for(i in seq(nbootstrap)){
    # Randomly reweight each variable
    # xs <- t(t(x)*runif(p,alpha,1))
    
    # Ramdomly split the sample in two sets
    i1 <- sample(pidx,floor(lp/2))
    i2 <- setdiff(pidx,i1)
    
    i1t <- sample(nidx,floor(ln/2))
    i2t <- setdiff(nidx,i1t)
    
    i1 <- c(i1,i1t)
    i2 <- c(i2,i2t)

    # run the randomized lasso on each sample and 
    # check which variables are selected
    w <- runif(kp,alpha,1)
    r <- comlasso("classification", length(i1), p=1, K=kp, x[i1,], y[i1], gam, 
          weights=w, max.steps=nsteps*10, trace=trace)
    
    bvec <- r$beta.rec[[1]]

    
    freq <- freq + abs(sign(bvec))
    
    w <- runif(kp,alpha,1)
    r <- comlasso("classification", length(i2), p=1, K=kp, x[i2,], y[i2], gam, 
          weights=w, max.steps=nsteps*10, trace=trace)
    bvec <- r$beta.rec[[1]]
    freq <- freq + abs(sign(bvec))
print(dim(freq))
print(dim(bvec))
  }
  # normalize frequence in [0,1]
  freq <- freq/(2*nbootstrap)
  
  if(plotme){
    matplot(t(freq), type='l',xlab="CLasso iteration",ylab="Frequency",ylim=c(0,1))
  }
  # the final stability score is the maximum frequency over the steps
  result <- apply(freq,1,max)
  return(result)
}


